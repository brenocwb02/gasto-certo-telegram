-- Limpar TODOS os rate limits para resolver o problema imediatamente
TRUNCATE TABLE rate_limits;